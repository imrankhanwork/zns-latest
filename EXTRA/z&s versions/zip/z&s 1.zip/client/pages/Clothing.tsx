import { SaleBanner } from "@/components/SaleBanner";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";

export default function Clothing() {
  return (
    <div className="min-h-screen">
      <SaleBanner />
      <Navigation />
      <main className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-foreground mb-8">
            Clothing Collection
          </h1>
          <p className="text-lg text-muted-foreground">
            Our custom clothing collection coming soon...
          </p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
