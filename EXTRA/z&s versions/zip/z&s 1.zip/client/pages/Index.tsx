import { SaleBanner } from "@/components/SaleBanner";
import { Navigation } from "@/components/Navigation";
import { HeroSection } from "@/components/HeroSection";
import { FeaturedProducts } from "@/components/FeaturedProducts";
import { CustomStickersCTA } from "@/components/CustomStickersCTA";
import { QualityHighlights } from "@/components/QualityHighlights";
import { Footer } from "@/components/Footer";

export default function Index() {
  return (
    <div className="min-h-screen">
      <SaleBanner />
      <Navigation />
      <main>
        <HeroSection />
        <FeaturedProducts />
        <CustomStickersCTA />
        <QualityHighlights />
      </main>
      <Footer />
    </div>
  );
}
