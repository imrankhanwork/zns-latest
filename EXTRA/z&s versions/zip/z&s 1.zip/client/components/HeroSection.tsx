import { Button } from "@/components/ui/button";
import { ProductCarousel } from "./ProductCarousel";

export function HeroSection() {
  return (
    <section className="min-h-screen bg-gradient-to-br from-background via-background to-muted/50 flex items-center">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 pb-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left side - Text content */}
          <div className="space-y-8 text-center lg:text-left">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-6xl font-bold text-foreground leading-tight">
                PRINT
                <br />
                <span className="bg-gradient-to-r from-brand-pink via-brand-purple to-brand-blue bg-clip-text text-transparent">
                  WHATEVER
                </span>
                <br />
                YOU WANT
              </h1>
              <p className="text-lg text-muted-foreground max-w-md mx-auto lg:mx-0">
                From T-shirt designs to stickers that fit your style – express
                your creativity with our custom printing services. We do
                everything right here, so you have it your way!
              </p>
            </div>

            <Button
              size="lg"
              className="bg-gradient-to-r from-brand-pink to-brand-purple hover:from-brand-purple hover:to-brand-pink text-white font-semibold px-8 py-6 text-lg rounded-full shadow-lg transform hover:scale-105 transition-all duration-200"
            >
              ORDER NOW
            </Button>
          </div>

          {/* Right side - Product carousel (hidden on mobile) */}
          <div className="flex items-center justify-center">
            <ProductCarousel />
          </div>
        </div>
      </div>
    </section>
  );
}
