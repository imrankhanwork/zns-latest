import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { CheckCircle, Zap, Heart, Star, Users } from "lucide-react";

const highlights = [
  {
    id: "quality",
    icon: CheckCircle,
    title: "Premium Quality",
    content:
      "We have put an effort to give every customer maximum satisfaction with our premium quality vinyl Sticker.",
  },
  {
    id: "innovation",
    icon: Zap,
    title: "Industry Innovation",
    content:
      "Leading the way with cutting-edge printing technology and innovative design solutions that set industry standards.",
  },
  {
    id: "service",
    icon: Heart,
    title: "Excellent Service",
    content:
      "Our dedicated customer service team ensures your experience is smooth from order to delivery with 24/7 support.",
  },
  {
    id: "designs",
    icon: Star,
    title: "Designs You Love",
    content:
      "Curated collections and custom design options that match your unique style and personality perfectly.",
  },
  {
    id: "customers",
    icon: Users,
    title: "Over 3 Million+ Stickers Sold",
    content:
      "Join millions of satisfied customers who trust us for their custom printing and sticker needs worldwide.",
  },
];

export function QualityHighlights() {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left side - Image */}
          <div className="relative">
            <div className="aspect-[4/3] bg-muted rounded-2xl overflow-hidden">
              <img
                src="/placeholder.svg"
                alt="Laptop with stickers being peeled"
                className="w-full h-full object-cover"
              />
            </div>
            {/* "PEEL PEEL" text overlay */}
            <div className="absolute bottom-4 left-4">
              <div className="text-6xl font-bold text-foreground/20 select-none">
                PEEL PEEL
              </div>
            </div>
          </div>

          {/* Right side - Accordion */}
          <div className="space-y-6">
            <div className="space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground">
                Why Choose Z&S Designs?
              </h2>
              <p className="text-lg text-muted-foreground">
                Discover what makes us the preferred choice for custom printing
                and design solutions.
              </p>
            </div>

            <Accordion type="single" collapsible className="w-full space-y-2">
              {highlights.map((highlight) => {
                const Icon = highlight.icon;
                return (
                  <AccordionItem
                    key={highlight.id}
                    value={highlight.id}
                    className="border border-border rounded-lg px-4"
                  >
                    <AccordionTrigger className="hover:no-underline">
                      <div className="flex items-center gap-3">
                        <Icon className="h-5 w-5 text-primary" />
                        <span className="font-semibold text-left">
                          {highlight.title}
                        </span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground pt-2 pb-4">
                      {highlight.content}
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>
          </div>
        </div>
      </div>
    </section>
  );
}
