import { Card, CardContent } from "@/components/ui/card";

const featuredProducts = [
  {
    id: 1,
    title: "Laptop Skins",
    image: "/placeholder.svg",
    category: "Premium Quality Vinyl",
  },
  {
    id: 2,
    title: "Phone Cases",
    image: "/placeholder.svg",
    category: "Custom Designs",
  },
  {
    id: 3,
    title: "Custom Stickers",
    image: "/placeholder.svg",
    category: "Weatherproof",
  },
  {
    id: 4,
    title: "T-Shirt Prints",
    image: "/placeholder.svg",
    category: "High Quality Cotton",
  },
  {
    id: 5,
    title: "Water Bottles",
    image: "/placeholder.svg",
    category: "Personalized Labels",
  },
  {
    id: 6,
    title: "Tote Bags",
    image: "/placeholder.svg",
    category: "Eco-Friendly",
  },
];

export function FeaturedProducts() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Featured Products
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover our most popular items crafted with premium materials and
            stunning designs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredProducts.map((product) => (
            <Card
              key={product.id}
              className="group hover:shadow-lg transition-all duration-300 transform hover:-translate-y-2 border-0 bg-card/50 backdrop-blur-sm"
            >
              <CardContent className="p-6">
                <div className="aspect-square bg-gradient-to-br from-muted to-muted/50 rounded-lg mb-4 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <div className="space-y-2">
                  <span className="text-sm text-primary font-medium">
                    {product.category}
                  </span>
                  <h3 className="text-lg font-semibold text-foreground">
                    {product.title}
                  </h3>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
