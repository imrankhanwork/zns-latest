import {
  Facebook,
  Instagram,
  Youtube,
  MapPin,
  Phone,
  Mail,
} from "lucide-react";

export function Footer() {
  const quickLinks = [
    "Stickers",
    "Skins",
    "Shirts",
    "Custom",
    "Reviews",
    "Mystery Box",
    "New Arrivals",
  ];

  const supportLinks = [
    "Track Order",
    "FAQ",
    "Terms & Conditions",
    "Privacy",
    "Shipping Policy",
    "Bulk Orders",
    "Blog",
    "Contact Us",
  ];

  return (
    <footer className="bg-foreground text-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand section */}
          <div className="space-y-4">
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-brand-pink via-brand-purple to-brand-blue flex items-center justify-center">
                <span className="text-white font-bold text-lg">Z&S</span>
              </div>
              <span className="ml-2 text-xl font-bold">DESIGNS</span>
            </div>
            <p className="text-sm text-background/80 italic">
              "There's a sticker for that!? Yes..."
            </p>
            <p className="text-sm text-background/60">Made with ♥ in India</p>
          </div>

          {/* Contact info */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Contact Info</h3>
            <div className="space-y-2 text-sm text-background/80">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span>+91 7506232907</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <span>hello@zsdesigns.com</span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-0.5" />
                <span>
                  Z&S Designs, Creative Hub, Sector 21,
                  <br />
                  Behind Tech Plaza, Delhi,
                  <br />
                  New Delhi, India 110001
                </span>
              </div>
            </div>
          </div>

          {/* Quick links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Quick Links</h3>
            <div className="grid grid-cols-2 gap-1 text-sm">
              {quickLinks.map((link) => (
                <a
                  key={link}
                  href={`/${link.toLowerCase().replace(" ", "-")}`}
                  className="text-background/80 hover:text-background transition-colors"
                >
                  {link}
                </a>
              ))}
            </div>
          </div>

          {/* Support */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Information & Support</h3>
            <div className="space-y-1 text-sm">
              {supportLinks.map((link) => (
                <a
                  key={link}
                  href={`/${link.toLowerCase().replace(/\s+/g, "-").replace("&", "and")}`}
                  className="block text-background/80 hover:text-background transition-colors"
                >
                  {link}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom section */}
        <div className="mt-12 pt-8 border-t border-background/20">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-background/60">
              © 2024 Z&S Designs. All rights reserved.
            </p>

            {/* Social links */}
            <div className="flex items-center gap-4">
              <a
                href="#"
                className="text-background/60 hover:text-background transition-colors"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="text-background/60 hover:text-background transition-colors"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="text-background/60 hover:text-background transition-colors"
              >
                <Youtube className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="text-background/60 hover:text-background transition-colors"
              >
                <svg
                  className="h-5 w-5"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.174-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.097.118.11.221.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.402.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.357-.629-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24.009 12.017 24.009c6.624 0 11.99-5.367 11.99-11.988C24.007 5.367 18.641.001 12.017.001z" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
