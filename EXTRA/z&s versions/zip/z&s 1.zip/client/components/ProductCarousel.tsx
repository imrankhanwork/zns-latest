interface Product {
  id: number;
  name: string;
  category: string;
  bgColor: string;
  image: string;
}

const products: Product[] = [
  {
    id: 1,
    name: "T-SHIRTS AND JERSEY DESIGN PRINT",
    category: "T-SHIRTS AND JERSEY DESIGN PRINT",
    bgColor: "bg-[#E8F4F8]",
    image:
      "https://cdn.builder.io/api/v1/image/assets%2F19c44f29f12f4418b230723c58633cb4%2F3795b51fbd4b493ab01f31126a2f668e?format=webp&width=800",
  },
  {
    id: 2,
    name: "PRODUCT AND LABEL PRINT",
    category: "PRODUCT AND LABEL PRINT",
    bgColor: "bg-[#E8F5E8]",
    image:
      "https://cdn.builder.io/api/v1/image/assets%2F19c44f29f12f4418b230723c58633cb4%2F55540923cf904d6a8df6646bd294aa09?format=webp&width=800",
  },
  {
    id: 3,
    name: "IPHONE BACK COVER PRINTS",
    category: "IPHONE BACK COVER PRINTS",
    bgColor: "bg-[#FFF8E1]",
    image:
      "https://cdn.builder.io/api/v1/image/assets%2F19c44f29f12f4418b230723c58633cb4%2F55540923cf904d6a8df6646bd294aa09?format=webp&width=800",
  },
  {
    id: 4,
    name: "SHOPPING BAGS PRINTS",
    category: "SHOPPING BAGS PRINTS",
    bgColor: "bg-[#FDF2F8]",
    image:
      "https://cdn.builder.io/api/v1/image/assets%2F19c44f29f12f4418b230723c58633cb4%2F55540923cf904d6a8df6646bd294aa09?format=webp&width=800",
  },
];

import { useState, useEffect } from "react";

export function ProductCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % products.length);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="hidden lg:block w-full max-w-6xl mx-auto">
      <div
        className="relative h-96 flex items-center justify-center"
        style={{ perspective: "1200px" }}
      >
        {products.map((product, index) => {
          const position =
            (index - currentIndex + products.length) % products.length;

          return (
            <div
              key={product.id}
              className="absolute transition-all duration-1000 ease-in-out"
              style={{
                transformOrigin: "center center",
                transform: `${
                  position === 0
                    ? "translateX(-10rem) translateY(3rem) scale(1.1) rotateY(0deg)"
                    : position === 1
                      ? "translateX(-3rem) translateY(1rem) scale(1) rotateY(8deg)"
                      : position === 2
                        ? "translateX(4rem) translateY(-1rem) scale(0.9) rotateY(16deg)"
                        : "translateX(10rem) translateY(-3rem) scale(0.8) rotateY(24deg)"
                }`,
                zIndex: products.length - position,
                perspective: "1200px",
                transformStyle: "preserve-3d",
              }}
            >
              <div
                className={`w-52 h-72 rounded-2xl ${product.bgColor} p-4 flex flex-col items-center justify-between shadow-xl relative overflow-hidden`}
              >
                {/* Product image area */}
                <div className="flex-1 flex items-center justify-center w-full pt-2">
                  <div className="w-36 h-40 flex items-center justify-center">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-contain drop-shadow-lg"
                    />
                  </div>
                </div>

                {/* Category and title */}
                <div className="text-center w-full pb-2 px-2">
                  <div className="flex items-center justify-center mb-2">
                    <div className="w-2 h-2 bg-[#00A8CC] rounded-full mr-2"></div>
                    <span className="text-xs text-gray-600 uppercase tracking-wide font-medium">
                      {product.category}
                    </span>
                  </div>
                  <h3 className="text-xs font-bold text-gray-800 leading-tight">
                    {product.name}
                  </h3>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Carousel indicators */}
      <div className="flex justify-center mt-6 space-x-1">
        {products.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`w-1.5 h-1.5 rounded-full transition-colors ${
              index === currentIndex ? "bg-gray-700" : "bg-gray-400"
            }`}
          />
        ))}
      </div>
    </div>
  );
}
