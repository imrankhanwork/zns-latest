import { useState } from "react";
import { X } from "lucide-react";
import { useCountdown } from "@/hooks/useCountdown";

export function SaleBanner() {
  const [isVisible, setIsVisible] = useState(true);

  // Set sale end date (example: 7 days from now)
  const saleEndDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
  const timeLeft = useCountdown(saleEndDate);

  if (!isVisible) return null;

  return (
    <div className="relative">
      {/* Red timer bar */}
      <div className="bg-sale-red text-white py-2 px-4 text-center text-sm font-medium relative">
        <div className="flex items-center justify-center gap-2">
          <span>HURRY! SALE ENDS IN :</span>
          <span className="font-bold">
            {timeLeft.days} days {String(timeLeft.hours).padStart(2, "0")} hrs{" "}
            {String(timeLeft.minutes).padStart(2, "0")} mins{" "}
            {String(timeLeft.seconds).padStart(2, "0")} secs
          </span>
        </div>
        <button
          onClick={() => setIsVisible(false)}
          className="absolute right-4 top-1/2 -translate-y-1/2 hover:opacity-80"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Yellow shipping bar */}
      <div className="bg-sale-yellow text-black py-2 px-4 text-center text-sm font-medium">
        FREE SHIPPING OVER ₹399
      </div>
    </div>
  );
}
