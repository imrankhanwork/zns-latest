import { Button } from "@/components/ui/button";

export function CustomStickersCTA() {
  return (
    <section className="py-20 bg-gradient-to-r from-brand-yellow/20 via-brand-orange/20 to-brand-pink/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left side - Image */}
          <div className="relative">
            <div className="aspect-[4/3] bg-gradient-to-br from-brand-yellow/30 to-brand-orange/30 rounded-2xl overflow-hidden">
              <img
                src="/placeholder.svg"
                alt="Person with custom sticker laptop"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-4 -right-4 w-20 h-20 bg-gradient-to-br from-brand-pink to-brand-purple rounded-full opacity-20"></div>
            <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-gradient-to-br from-brand-blue to-brand-green rounded-full opacity-20"></div>
          </div>

          {/* Right side - Content */}
          <div className="space-y-6">
            <h2 className="text-3xl md:text-5xl font-bold text-foreground leading-tight">
              NOW MAKE YOUR OWN
              <br />
              <span className="bg-gradient-to-r from-brand-pink via-brand-purple to-brand-blue bg-clip-text text-transparent">
                CUSTOM STICKERS
              </span>
            </h2>

            <div className="space-y-4 text-lg text-muted-foreground">
              <p>
                Make your own customer stickers, custom labels with few easy
                steps.
              </p>
              <p>Let's create stories with STICK IT UP's Custom stickers.</p>
            </div>

            <Button
              size="lg"
              className="bg-gradient-to-r from-brand-blue to-brand-purple hover:from-brand-purple hover:to-brand-blue text-white font-semibold px-8 py-6 text-lg rounded-full shadow-lg transform hover:scale-105 transition-all duration-200"
            >
              SHOP NOW
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
