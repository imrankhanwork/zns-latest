
import React from 'react';
import { Button } from '@/components/ui/button';

interface CustomStickerCTAProps {
  isDarkMode: boolean;
}

const CustomStickerCTA: React.FC<CustomStickerCTAProps> = ({ isDarkMode }) => {
  return (
    <section className={`py-16 ${isDarkMode ? 'bg-gradient-to-r from-purple-900 to-blue-900' : 'bg-gradient-to-r from-yellow-300 to-blue-500'} transition-colors duration-300`}>
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          {/* Image Side */}
          <div className="lg:w-1/2">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=600&h=400&fit=crop"
                alt="Happy customer with custom stickers"
                className="rounded-2xl shadow-2xl w-full h-[400px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/20 to-transparent rounded-2xl" />
            </div>
          </div>

          {/* Content Side */}
          <div className="lg:w-1/2 text-center lg:text-left">
            <h2 className={`text-4xl lg:text-5xl font-bold mb-6 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              NOW MAKE YOUR OWN
              <br />
              <span className={`${isDarkMode ? 'text-yellow-400' : 'text-blue-800'}`}>
                CUSTOM STICKERS
              </span>
            </h2>
            
            <p className={`text-lg mb-6 ${isDarkMode ? 'text-gray-200' : 'text-gray-700'} max-w-md mx-auto lg:mx-0`}>
              Make your own customer stickers, custom labels with few east steps.
            </p>
            
            <p className={`text-lg mb-8 ${isDarkMode ? 'text-gray-200' : 'text-gray-700'} max-w-md mx-auto lg:mx-0`}>
              Lets create stories with STICK IT UP's Custom stickers.
            </p>

            <Button 
              size="lg"
              className={`${isDarkMode ? 'bg-yellow-400 hover:bg-yellow-500 text-black' : 'bg-blue-600 hover:bg-blue-700 text-white'} px-12 py-4 text-xl font-bold rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg`}
            >
              SHOP NOW
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CustomStickerCTA;
