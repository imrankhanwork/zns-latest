
import React from 'react';
import { Facebook, Instagram, Youtube, MapPin, Phone, Mail } from 'lucide-react';

interface FooterProps {
  isDarkMode: boolean;
}

const Footer: React.FC<FooterProps> = ({ isDarkMode }) => {
  return (
    <footer className={`py-12 ${isDarkMode ? 'bg-gray-900 border-gray-700' : 'bg-gray-900'} text-white`}>
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Left Column - Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <img 
                src="/lovable-uploads/7478e966-d1c5-4b1a-8b42-cadc29672a30.png" 
                alt="Z&S DESIGNS" 
                className="h-12 w-auto"
              />
            </div>
            <p className="text-gray-300 max-w-sm">
              There's a sticker for that!? Yes, there's a sticker for everyone.
            </p>
            <div className="text-yellow-400 font-semibold">
              Made with ♥ in India
            </div>
            
            {/* Contact Info */}
            <div className="space-y-2 text-sm text-gray-300">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                <span>+91 7506232907</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                <span>wecare@stickitup.xyz</span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-1" />
                <span>
                  Stickitup, Arthi Road, Dahisar East, behind Rajshree Cinema,<br />
                  Mumbai, Maharashtra 400068
                </span>
              </div>
            </div>
          </div>

          {/* Center Column - Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">QUICK LINKS</h3>
            <div className="space-y-2">
              <a href="#" className="block text-gray-300 hover:text-yellow-400 transition-colors">Stickers</a>
              <a href="#" className="block text-gray-300 hover:text-yellow-400 transition-colors">Mini Sticker Sheets</a>
              <a href="#" className="block text-gray-300 hover:text-yellow-400 transition-colors">Laptop Skins</a>
              <a href="#" className="block text-gray-300 hover:text-yellow-400 transition-colors">Credit Card Skins</a>
              <a href="#" className="block text-gray-300 hover:text-yellow-400 transition-colors">About Us</a>
              <a href="#" className="block text-gray-300 hover:text-yellow-400 transition-colors">Track Your Order</a>
            </div>
          </div>

          {/* Right Column - Information & Support */}
          <div>
            <h3 className="text-lg font-semibold mb-4">INFORMATION & SUPPORT</h3>
            <div className="space-y-2">
              <a href="#" className="block text-gray-300 hover:text-yellow-400 transition-colors">Track Your Order</a>
              <a href="#" className="block text-gray-300 hover:text-yellow-400 transition-colors">Frequently Asked Questions</a>
              <a href="#" className="block text-gray-300 hover:text-yellow-400 transition-colors">Terms & Conditions</a>
              <a href="#" className="block text-gray-300 hover:text-yellow-400 transition-colors">Privacy Policy</a>
              <a href="#" className="block text-gray-300 hover:text-yellow-400 transition-colors">Refund Policy</a>
              <a href="#" className="block text-gray-300 hover:text-yellow-400 transition-colors">Shipping Policy</a>
              <a href="#" className="block text-gray-300 hover:text-yellow-400 transition-colors">Bulk & Custom Orders</a>
              <a href="#" className="block text-gray-300 hover:text-yellow-400 transition-colors">Blog</a>
              <a href="#" className="block text-gray-300 hover:text-yellow-400 transition-colors">Contact Us</a>
            </div>
          </div>
        </div>

        {/* Social Media Icons */}
        <div className="mt-8 pt-8 border-t border-gray-700 flex justify-center space-x-6">
          <a href="#" className="text-gray-400 hover:text-yellow-400 transition-colors">
            <Facebook className="w-6 h-6" />
          </a>
          <a href="#" className="text-gray-400 hover:text-yellow-400 transition-colors">
            <Instagram className="w-6 h-6" />
          </a>
          <a href="#" className="text-gray-400 hover:text-yellow-400 transition-colors">
            <Youtube className="w-6 h-6" />
          </a>
          <a href="#" className="text-gray-400 hover:text-yellow-400 transition-colors">
            <MapPin className="w-6 h-6" />
          </a>
        </div>

        {/* Copyright */}
        <div className="mt-8 pt-4 border-t border-gray-700 text-center text-gray-400 text-sm">
          <p>&copy; 2024 Z&S DESIGNS. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
