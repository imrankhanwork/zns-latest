
import React, { useState } from 'react';
import { ChevronDown, Check, Zap, Heart, Star, Award } from 'lucide-react';

interface QualityAccordionProps {
  isDarkMode: boolean;
}

const QualityAccordion: React.FC<QualityAccordionProps> = ({ isDarkMode }) => {
  const [openAccordion, setOpenAccordion] = useState<string | null>('premium');

  const accordionItems = [
    {
      id: 'premium',
      title: 'Premium Quality',
      icon: <Check className="w-5 h-5" />,
      content: 'We have put an effort to give every customer maximum satisfaction with our premium quality vinyl Sticker.'
    },
    {
      id: 'innovation',
      title: 'Industry Innovation',
      icon: <Zap className="w-5 h-5" />,
      content: 'Leading the industry with cutting-edge printing technology and innovative design solutions that set new standards.'
    },
    {
      id: 'service',
      title: 'Excellent Service',
      icon: <Heart className="w-5 h-5" />,
      content: 'Our dedicated customer service team ensures every order is handled with care and delivered with excellence.'
    },
    {
      id: 'designs',
      title: 'Designs You Love',
      icon: <Star className="w-5 h-5" />,
      content: 'Curated collection of trendy, unique designs that match your style and personality perfectly.'
    },
    {
      id: 'sold',
      title: 'Over 3 Million+ Stickers Sold',
      icon: <Award className="w-5 h-5" />,
      content: 'Trusted by millions of customers worldwide with a proven track record of quality and satisfaction.'
    }
  ];

  const toggleAccordion = (id: string) => {
    setOpenAccordion(openAccordion === id ? null : id);
  };

  return (
    <section className={`py-16 ${isDarkMode ? 'bg-gray-800' : 'bg-white'} transition-colors duration-300`}>
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Image Side */}
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=600&h=500&fit=crop"
              alt="Laptop with stickers being peeled"
              className="rounded-2xl shadow-2xl w-full h-[500px] object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent rounded-2xl" />
            
            {/* Floating Badge */}
            <div className="absolute top-6 right-6 bg-yellow-400 text-black px-4 py-2 rounded-full font-bold text-sm shadow-lg">
              PEEL PEEL
            </div>
          </div>

          {/* Accordion Side */}
          <div className="space-y-4">
            {accordionItems.map((item) => (
              <div
                key={item.id}
                className={`border rounded-lg overflow-hidden transition-all duration-300 ${
                  isDarkMode ? 'border-gray-600 bg-gray-700' : 'border-gray-200 bg-gray-50'
                } ${openAccordion === item.id ? 'shadow-lg' : 'shadow-sm'}`}
              >
                <button
                  onClick={() => toggleAccordion(item.id)}
                  className={`w-full px-6 py-4 text-left flex items-center justify-between transition-colors duration-200 ${
                    isDarkMode ? 'hover:bg-gray-600' : 'hover:bg-gray-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`${isDarkMode ? 'text-yellow-400' : 'text-blue-600'}`}>
                      {item.icon}
                    </div>
                    <span className={`font-semibold text-lg ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      {item.title}
                    </span>
                  </div>
                  <ChevronDown
                    className={`w-5 h-5 transition-transform duration-300 ${
                      openAccordion === item.id ? 'rotate-180' : ''
                    } ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}
                  />
                </button>
                
                <div
                  className={`overflow-hidden transition-all duration-300 ${
                    openAccordion === item.id ? 'max-h-40 opacity-100' : 'max-h-0 opacity-0'
                  }`}
                >
                  <div className={`px-6 pb-4 ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                    {item.content}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default QualityAccordion;
