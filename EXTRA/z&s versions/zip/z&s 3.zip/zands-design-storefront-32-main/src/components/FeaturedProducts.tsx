
import React from 'react';
import { Star, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface FeaturedProductsProps {
  isDarkMode: boolean;
}

const products = [
  {
    id: 1,
    name: "Limited Edition V2 Sticker",
    originalPrice: 79,
    salePrice: 19,
    image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=300&h=300&fit=crop",
    badge: "Sale",
    isNew: true
  },
  {
    id: 2,
    name: "Wasted Sticker",
    originalPrice: 79,
    salePrice: 19,
    image: "https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=300&h=300&fit=crop",
    badge: "Sale"
  },
  {
    id: 3,
    name: "NOS Sticker",
    originalPrice: 79,
    salePrice: 19,
    image: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?w=300&h=300&fit=crop",
    badge: "Sale"
  },
  {
    id: 4,
    name: "Compass V2 Sticker",
    originalPrice: 79,
    salePrice: 19,
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=300&h=300&fit=crop",
    badge: "Sale",
    isNew: true
  },
  {
    id: 5,
    name: "Gaming Laptop Skin",
    originalPrice: 299,
    salePrice: 199,
    image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=300&h=300&fit=crop",
    badge: "Hot"
  },
  {
    id: 6,
    name: "Phone Skin Collection",
    originalPrice: 149,
    salePrice: 99,
    image: "https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=300&h=300&fit=crop",
    badge: "Sale"
  }
];

const FeaturedProducts: React.FC<FeaturedProductsProps> = ({ isDarkMode }) => {
  return (
    <section className={`py-16 ${isDarkMode ? 'bg-gray-900' : 'bg-gray-50'} transition-colors duration-300`}>
      <div className="container mx-auto px-4">
        {/* HOT PICKS Section */}
        <div className="mb-16">
          <h2 className={`text-4xl font-bold mb-12 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
            HOT PICKS
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {products.slice(0, 4).map((product) => (
              <div key={product.id} className="group relative">
                {/* Product Card */}
                <div className={`relative overflow-hidden rounded-2xl ${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg transition-all duration-300 hover:shadow-2xl hover:scale-105`}>
                  {/* Badges */}
                  <div className="absolute top-4 left-4 z-10 flex gap-2">
                    {product.isNew && (
                      <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
                        NEW
                      </span>
                    )}
                    <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
                      {product.badge}
                    </span>
                  </div>

                  {/* Product Image */}
                  <div className="aspect-square overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                  </div>

                  {/* Product Info */}
                  <div className="p-4">
                    <h3 className={`font-semibold text-lg mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      {product.name}
                    </h3>
                    
                    <div className="flex items-center gap-2 mb-3">
                      <span className={`text-sm line-through ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                        Rs. {product.originalPrice}.00
                      </span>
                      <span className={`text-xl font-bold ${isDarkMode ? 'text-yellow-400' : 'text-blue-600'}`}>
                        Rs. {product.salePrice}.00
                      </span>
                    </div>

                    <Button 
                      className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-semibold py-2 rounded-lg transition-colors duration-200"
                    >
                      Add to cart
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* More Products Section */}
        <div>
          <h2 className={`text-3xl font-bold mb-8 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
            More Products
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.slice(4).map((product) => (
              <div key={product.id} className="group relative">
                <div className={`relative overflow-hidden rounded-2xl ${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg transition-all duration-300 hover:shadow-2xl hover:scale-105`}>
                  <div className="absolute top-4 left-4 z-10">
                    <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
                      {product.badge}
                    </span>
                  </div>

                  <div className="aspect-square overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                  </div>

                  <div className="p-4">
                    <h3 className={`font-semibold text-lg mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      {product.name}
                    </h3>
                    
                    <div className="flex items-center gap-2 mb-3">
                      <span className={`text-sm line-through ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                        Rs. {product.originalPrice}.00
                      </span>
                      <span className={`text-xl font-bold ${isDarkMode ? 'text-yellow-400' : 'text-blue-600'}`}>
                        Rs. {product.salePrice}.00
                      </span>
                    </div>

                    <div className="flex items-center mb-3">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      ))}
                      <span className={`ml-2 text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                        (4.9)
                      </span>
                    </div>

                    <Button 
                      className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-semibold py-2 rounded-lg transition-colors duration-200 flex items-center justify-center gap-2"
                    >
                      <ShoppingCart size={16} />
                      Add to cart
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;
