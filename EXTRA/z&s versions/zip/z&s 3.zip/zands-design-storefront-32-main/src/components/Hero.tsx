

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';

interface HeroProps {
  isDarkMode: boolean;
}

const lightModeProducts = [
  {
    id: 1,
    name: "Geometric Laptop Skin",
    image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=400&h=600&fit=crop",
    productImage: "https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=300&h=200&fit=crop",
    dominantColor: "from-blue-400 to-purple-500"
  },
  {
    id: 2,
    name: "Minimalist Phone Case",
    image: "https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=400&h=600&fit=crop",
    productImage: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=300&h=200&fit=crop",
    dominantColor: "from-pink-400 to-red-500"
  },
  {
    id: 3,
    name: "Custom T-Shirt Design",
    image: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?w=400&h=600&fit=crop",
    productImage: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=300&h=200&fit=crop",
    dominantColor: "from-green-400 to-blue-500"
  },
  {
    id: 4,
    name: "Sticker Pack Collection",
    image: "https://images.unsplash.com/photo-1582562124811-c09040d0a901?w=400&h=600&fit=crop",
    productImage: "https://images.unsplash.com/photo-1721322800607-8c38375eef04?w=300&h=200&fit=crop",
    dominantColor: "from-yellow-400 to-orange-500"
  }
];

const darkModeProducts = [
  {
    id: 1,
    name: "Neon Cyber Laptop Skin",
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=600&fit=crop",
    productImage: "https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=300&h=200&fit=crop",
    dominantColor: "from-purple-600 to-pink-600"
  },
  {
    id: 2,
    name: "Glow Phone Skin",
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=600&fit=crop",
    productImage: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=300&h=200&fit=crop",
    dominantColor: "from-cyan-600 to-blue-600"
  },
  {
    id: 3,
    name: "Dark Tech T-Shirt",
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=600&fit=crop",
    productImage: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=300&h=200&fit=crop",
    dominantColor: "from-red-600 to-orange-600"
  },
  {
    id: 4,
    name: "Neon Sticker Pack",
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=600&fit=crop",
    productImage: "https://images.unsplash.com/photo-1721322800607-8c38375eef04?w=300&h=200&fit=crop",
    dominantColor: "from-green-600 to-teal-600"
  }
];

const Hero: React.FC<HeroProps> = ({ isDarkMode }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const products = isDarkMode ? darkModeProducts : lightModeProducts;

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % products.length);
    }, 3000);
    return () => clearInterval(timer);
  }, [products.length]);

  const currentProduct = products[currentIndex];

  // Helper function to get desktop card position and styling with equal spacing
  const getDesktopCardPosition = (index: number) => {
    const position = (index - currentIndex + products.length) % products.length;
    const cardWidth = 240; // Base card width
    const spacing = 80; // Increased spacing to ensure all cards are visible with equal gaps
    
    const positions = [
      { translateX: 0, scale: 1, rotateY: 0, zIndex: 40, opacity: 1 },
      { translateX: cardWidth + spacing, scale: 0.9, rotateY: 15, zIndex: 30, opacity: 0.9 },
      { translateX: (cardWidth + spacing) * 2, scale: 0.8, rotateY: 25, zIndex: 20, opacity: 0.8 },
      { translateX: (cardWidth + spacing) * 3, scale: 0.7, rotateY: 35, zIndex: 10, opacity: 0.7 }
    ];

    return positions[position];
  };

  return (
    <section className={`relative min-h-[80vh] bg-gradient-to-br ${currentProduct.dominantColor} transition-colors duration-700 overflow-hidden`}>
      <div className="container mx-auto px-4 h-full flex items-center">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 w-full min-h-[70vh] items-center">
          {/* Left Content - 2/5 */}
          <div className="lg:col-span-2 text-white z-10 space-y-6">
            <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
              PRINT<br />
              WHATEVER<br />
              YOU WANT
            </h1>
            <p className="text-lg opacity-90 max-w-md">
              FROM T-SHIRT DESIGN TO STATIONERY, WE PRINT EVERYTHING. WE DO EVERYTHING WHAT OTHERS DON'T
            </p>
            <Button 
              size="lg" 
              className="bg-pink-500 hover:bg-pink-600 text-white px-8 py-3 text-lg font-semibold rounded-lg transition-all duration-300 transform hover:scale-105"
            >
              ORDER NOW →
            </Button>
          </div>

          {/* Right Carousel - 3/5 */}
          <div className="lg:col-span-3 relative flex items-center">
            {/* Mobile Carousel - Single card with horizontal scroll */}
            <div className="block lg:hidden">
              <div className="flex gap-6 overflow-x-auto snap-x snap-mandatory scrollbar-hide pb-4">
                {products.map((product, index) => (
                  <div
                    key={product.id}
                    className="flex-shrink-0 w-60 h-[360px] snap-center"
                    onClick={() => setCurrentIndex(index)}
                  >
                    <div 
                      className="relative w-full h-full rounded-2xl overflow-hidden shadow-2xl"
                      style={{
                        backgroundImage: `url(${product.image})`,
                        backgroundSize: 'cover',
                        backgroundPosition: 'center'
                      }}
                    >
                      {/* Overlay for better text contrast */}
                      <div className="absolute inset-0 bg-black/20 rounded-2xl" />
                      
                      {/* Floating Product Image - Nearly full size with 0.3cm padding equivalent */}
                      <div className="absolute inset-[3px] z-10">
                        <img
                          src={product.productImage}
                          alt={product.name}
                          className="absolute right-0 top-0 bottom-0 w-32 h-full object-contain drop-shadow-xl"
                        />
                      </div>
                      
                      {/* Product Info */}
                      <div className="absolute bottom-4 left-4 right-24 text-white z-20">
                        <h3 className="font-semibold text-lg mb-2 leading-tight">{product.name}</h3>
                        <div className="flex items-center text-sm opacity-90">
                          <div className="w-2 h-2 bg-white rounded-full mr-2" />
                          <span>Premium Quality</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Desktop Carousel - 4 cards with 3D animation and equal spacing */}
            <div className="hidden lg:block h-[500px] overflow-visible w-full max-w-6xl mx-auto">
              <div className="relative w-full h-full flex items-center pt-16" style={{ perspective: '1000px' }}>
                {products.map((product, index) => {
                  const cardStyle = getDesktopCardPosition(index);
                  
                  return (
                    <div
                      key={product.id}
                      className="absolute transition-all duration-1000 ease-in-out cursor-pointer"
                      style={{
                        transform: `translateX(${cardStyle.translateX}px) scale(${cardStyle.scale}) rotateY(${cardStyle.rotateY}deg)`,
                        transformOrigin: 'top center',
                        zIndex: cardStyle.zIndex,
                        opacity: cardStyle.opacity
                      }}
                      onClick={() => setCurrentIndex(index)}
                    >
                      {/* Product Card with 2:3 aspect ratio */}
                      <div 
                        className="relative w-60 h-[360px] rounded-2xl overflow-hidden shadow-2xl transition-transform duration-300 hover:scale-105"
                        style={{
                          backgroundImage: `url(${product.image})`,
                          backgroundSize: 'cover',
                          backgroundPosition: 'center'
                        }}
                      >
                        {/* Overlay for better text contrast */}
                        <div className="absolute inset-0 bg-black/20 rounded-2xl" />
                        
                        {/* Floating Product Image - Nearly full size with 0.3cm padding equivalent */}
                        <div className="absolute inset-[3px] z-10">
                          <img
                            src={product.productImage}
                            alt={product.name}
                            className="absolute right-0 top-0 bottom-0 w-40 h-full object-contain drop-shadow-xl transition-transform duration-300 hover:scale-110 hover:rotate-1"
                          />
                        </div>
                        
                        {/* Product Info - Bottom positioning */}
                        <div className="absolute bottom-4 left-4 right-24 text-white z-20">
                          <h3 className="font-semibold text-lg mb-2 leading-tight">{product.name}</h3>
                          <div className="flex items-center text-sm opacity-90">
                            <div className="w-2 h-2 bg-white rounded-full mr-2" />
                            <span>Premium Quality</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Dots Indicator */}
            <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-3 z-50">
              {products.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentIndex 
                      ? 'bg-white scale-125' 
                      : 'bg-white/50 hover:bg-white/75'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
