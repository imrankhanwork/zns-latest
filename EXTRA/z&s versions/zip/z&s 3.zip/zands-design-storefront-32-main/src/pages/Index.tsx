import React, { useState, useEffect } from 'react';
import { X, Search, User, ShoppingCart, ChevronDown, Sun, Moon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Hero from '@/components/Hero';
import FeaturedProducts from '@/components/FeaturedProducts';
import CustomStickerCTA from '@/components/CustomStickerCTA';
import QualityAccordion from '@/components/QualityAccordion';
import Footer from '@/components/Footer';

const Index = () => {
  const [showSaleBanner, setShowSaleBanner] = useState(true);
  const [saleTimeLeft, setSaleTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 55 });
  const [searchExpanded, setSearchExpanded] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [showShopDropdown, setShowShopDropdown] = useState(false);
  const [showSkinsDropdown, setShowSkinsDropdown] = useState(false);
  const [showClothingDropdown, setShowClothingDropdown] = useState(false);

  // Countdown timer logic
  useEffect(() => {
    const timer = setInterval(() => {
      setSaleTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else if (prev.days > 0) {
          return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        } else {
          setShowSaleBanner(false);
          return prev;
        }
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Dark mode persistence
  useEffect(() => {
    const savedMode = localStorage.getItem('darkMode');
    if (savedMode) {
      setIsDarkMode(JSON.parse(savedMode));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('darkMode', JSON.stringify(isDarkMode));
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDarkMode ? 'dark bg-gray-900' : 'bg-white'}`}>
      {/* Sale Banner */}
      {showSaleBanner && (
        <div className="bg-red-600 text-white py-3 px-4 text-center relative">
          <div className="flex items-center justify-center gap-2 text-sm font-medium">
            <span>HURRY! SALE ENDS IN :</span>
            <div className="flex gap-1">
              <span className="bg-white text-red-600 px-2 py-1 rounded text-xs font-bold">
                {saleTimeLeft.days}
              </span>
              <span className="text-xs">days</span>
              <span className="bg-white text-red-600 px-2 py-1 rounded text-xs font-bold">
                {String(saleTimeLeft.hours).padStart(2, '0')}
              </span>
              <span className="text-xs">hrs</span>
              <span className="bg-white text-red-600 px-2 py-1 rounded text-xs font-bold">
                {String(saleTimeLeft.minutes).padStart(2, '0')}
              </span>
              <span className="text-xs">mins</span>
              <span className="bg-white text-red-600 px-2 py-1 rounded text-xs font-bold">
                {String(saleTimeLeft.seconds).padStart(2, '0')}
              </span>
              <span className="text-xs">secs</span>
            </div>
          </div>
          <button
            onClick={() => setShowSaleBanner(false)}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 hover:bg-red-700 p-1 rounded"
          >
            <X size={16} />
          </button>
        </div>
      )}

      {/* Navigation */}
      <nav className={`sticky top-0 z-50 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border-b transition-colors duration-300`}>
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex-shrink-0">
              <img 
                src="/lovable-uploads/7478e966-d1c5-4b1a-8b42-cadc29672a30.png" 
                alt="Z&S DESIGNS" 
                className="h-12 w-auto"
              />
            </div>

            {/* Center Navigation - Hidden when search is expanded */}
            <div className={`hidden md:flex items-center space-x-8 ${searchExpanded ? 'opacity-0 pointer-events-none' : 'opacity-100'} transition-opacity duration-300`}>
              <div 
                className="relative"
                onMouseEnter={() => setShowShopDropdown(true)}
                onMouseLeave={() => setShowShopDropdown(false)}
              >
                <button className={`flex items-center gap-1 ${isDarkMode ? 'text-white hover:text-yellow-400' : 'text-gray-700 hover:text-blue-600'} transition-colors`}>
                  SHOP <ChevronDown size={16} />
                </button>
                {showShopDropdown && (
                  <div className={`absolute top-full left-0 mt-2 w-48 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border rounded-lg shadow-lg py-2 z-50`}>
                    <a href="#" className={`block px-4 py-2 ${isDarkMode ? 'text-white hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50'} transition-colors`}>All Products</a>
                    <a href="#" className={`block px-4 py-2 ${isDarkMode ? 'text-white hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50'} transition-colors`}>New Arrivals</a>
                    <a href="#" className={`block px-4 py-2 ${isDarkMode ? 'text-white hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50'} transition-colors`}>Best Sellers</a>
                  </div>
                )}
              </div>

              <div 
                className="relative"
                onMouseEnter={() => setShowSkinsDropdown(true)}
                onMouseLeave={() => setShowSkinsDropdown(false)}
              >
                <button className={`flex items-center gap-1 ${isDarkMode ? 'text-white hover:text-yellow-400' : 'text-gray-700 hover:text-blue-600'} transition-colors`}>
                  SKINS <ChevronDown size={16} />
                </button>
                {showSkinsDropdown && (
                  <div className={`absolute top-full left-0 mt-2 w-48 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border rounded-lg shadow-lg py-2 z-50`}>
                    <a href="#" className={`block px-4 py-2 ${isDarkMode ? 'text-white hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50'} transition-colors`}>Laptop Skins</a>
                    <a href="#" className={`block px-4 py-2 ${isDarkMode ? 'text-white hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50'} transition-colors`}>Phone Skins</a>
                    <a href="#" className={`block px-4 py-2 ${isDarkMode ? 'text-white hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50'} transition-colors`}>Tablet Skins</a>
                    <a href="#" className={`block px-4 py-2 ${isDarkMode ? 'text-white hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50'} transition-colors`}>Charger Skins</a>
                  </div>
                )}
              </div>

              <div 
                className="relative"
                onMouseEnter={() => setShowClothingDropdown(true)}
                onMouseLeave={() => setShowClothingDropdown(false)}
              >
                <button className={`flex items-center gap-1 ${isDarkMode ? 'text-white hover:text-yellow-400' : 'text-gray-700 hover:text-blue-600'} transition-colors`}>
                  CLOTHING <ChevronDown size={16} />
                </button>
                {showClothingDropdown && (
                  <div className={`absolute top-full left-0 mt-2 w-48 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border rounded-lg shadow-lg py-2 z-50`}>
                    <a href="#" className={`block px-4 py-2 ${isDarkMode ? 'text-white hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50'} transition-colors`}>T-Shirts</a>
                    <a href="#" className={`block px-4 py-2 ${isDarkMode ? 'text-white hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50'} transition-colors`}>Jerseys</a>
                  </div>
                )}
              </div>

              <a href="#" className={`${isDarkMode ? 'text-white hover:text-yellow-400' : 'text-gray-700 hover:text-blue-600'} transition-colors`}>STICKER PACKS</a>
              <a href="#" className={`${isDarkMode ? 'text-white hover:text-yellow-400' : 'text-gray-700 hover:text-blue-600'} transition-colors`}>MYSTERY BOX</a>
              <a href="#" className={`${isDarkMode ? 'text-white hover:text-yellow-400' : 'text-gray-700 hover:text-blue-600'} transition-colors`}>CUSTOM DESIGNS</a>
            </div>

            {/* Right Side Icons */}
            <div className="flex items-center space-x-4">
              {/* Search */}
              <div className={`relative ${searchExpanded ? 'w-64' : 'w-10'} transition-all duration-300`}>
                {searchExpanded ? (
                  <div className="flex items-center">
                    <input
                      type="text"
                      placeholder="Search products..."
                      className={`w-full px-4 py-2 rounded-lg border ${isDarkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-blue-500`}
                      autoFocus
                    />
                    <button 
                      onClick={() => setSearchExpanded(false)}
                      className={`ml-2 p-2 ${isDarkMode ? 'text-white hover:text-yellow-400' : 'text-gray-600 hover:text-blue-600'} transition-colors`}
                    >
                      <X size={20} />
                    </button>
                  </div>
                ) : (
                  <button 
                    onClick={() => setSearchExpanded(true)}
                    className={`p-2 ${isDarkMode ? 'text-white hover:text-yellow-400' : 'text-gray-600 hover:text-blue-600'} transition-colors`}
                  >
                    <Search size={20} />
                  </button>
                )}
              </div>

              {/* Dark Mode Toggle */}
              <button
                onClick={toggleDarkMode}
                className={`p-2 rounded-lg ${isDarkMode ? 'text-yellow-400 hover:bg-gray-700' : 'text-gray-600 hover:bg-gray-100'} transition-colors`}
              >
                {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
              </button>

              {/* Account */}
              <button className={`p-2 ${isDarkMode ? 'text-white hover:text-yellow-400' : 'text-gray-600 hover:text-blue-600'} transition-colors`}>
                <User size={20} />
              </button>

              {/* Cart */}
              <button className={`relative p-2 ${isDarkMode ? 'text-white hover:text-yellow-400' : 'text-gray-600 hover:text-blue-600'} transition-colors`}>
                <ShoppingCart size={20} />
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  3
                </span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main>
        <Hero isDarkMode={isDarkMode} />
        <FeaturedProducts isDarkMode={isDarkMode} />
        <CustomStickerCTA isDarkMode={isDarkMode} />
        <QualityAccordion isDarkMode={isDarkMode} />
      </main>

      <Footer isDarkMode={isDarkMode} />
    </div>
  );
};

export default Index;
